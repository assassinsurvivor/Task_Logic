import re 
import os
import copy
import random
import pickle
import itertools
import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow_datasets as tfds

from random import shuffle
from tqdm import tqdm_notebook
from sklearn.model_selection import KFold
from collections import defaultdict,Counter
from sklearn.preprocessing import OneHotEncoder


pattern_text=re.compile("[^a-z&-,\'\.]")

def ETL():
    df=pd.read_excel("NLP_data_scientist_test/data/Entity_sentiment_trainV2.xlsx")
    extracted_corpus=df["Sentence"].apply(lambda x:x.lower()).tolist()
    entities=df["Entity"].apply(lambda x:x.lower()).tolist()
    sentiment=df['Sentiment'].apply(lambda x:x.lower()).tolist()
    sentiment=[1 if i=='positive' else 0 for i in sentiment]

    for idx,i in enumerate(extracted_corpus):
        extracted_corpus[idx]=" ".join(z.strip() for z  in (pattern_text.sub(" ",i).strip().split()))
        extracted_corpus[idx]=" ".join (u.strip() for u in (" . ".join(k for k in [i.strip() for i in extracted_corpus[idx].split(".")] if k!="").split()))

    try:
        tokenizer=tfds.features.text.SubwordTextEncoder.load_from_file("tokenizer/tokenizer")
    except:
        tokenizer=tfds.features.text.SubwordTextEncoder.build_from_corpus((i for i in extracted_corpus),target_vocab_size=12000,reserved_tokens=["<mask>"]) 
        if not os.path.isdir("tokenizer"):
            os.mkdir("tokenizer")
        tokenizer.save_to_file("tokenizer/tokenizer")
      
    encode_train_data=[];mask_list=[];train_label=[]
    for idx,i in tqdm_notebook(enumerate(extracted_corpus)):
        sub_encode=[];sub_mask=[]
        splitter=i.split()
        sub_split=entities[idx].split()
        for u in splitter:
            var=tokenizer.encode(u)
            sub_encode+=var
            if u in sub_split:
                sub_mask+=[1.0]*len(var)
            else:
                sub_mask+=[0.0]*len(var)
            
        assert len(sub_mask)==len(sub_encode)
        encode_train_data.append(sub_encode)
        mask_list.append(sub_mask)
        train_label.append(sentiment[idx])

    print("Number of training samples before truncating to max sequence length of 1200:",len(encode_train_data))
    return encode_train_data,train_label,mask_list,tokenizer


def loader():
    data_save=dict()
    data_train,data_label,mask_list,token=ETL()
    kfold=KFold(5,True,42)
    fold_data=[]
    for _ in range(3):
        result=next(kfold.split(data_train,None))
        train_idx=result[0]
        test_idx=result[1]
        
        def generate_train_data():
            for _ in train_idx:
                yield data_train[_],data_label[_],mask_list[_]
        
        def generate_valid_data():
            for _ in test_idx:
                yield data_train[_],data_label[_],mask_list[_]

        batch_size=32
        buffer=1000000
        x_t=tf.data.Dataset.from_generator(generate_train_data,output_types=(tf.int32,tf.int32,tf.float32))
        x_t=x_t.cache().shuffle(buffer).padded_batch(batch_size,padded_shapes=([-1], [-1],[-1])).prefetch(tf.data.experimental.AUTOTUNE)
        x_v=tf.data.Dataset.from_generator(generate_valid_data,output_types=(tf.int32,tf.int32,tf.float32))
        x_v=x_v.cache().shuffle(buffer).padded_batch(batch_size,padded_shapes=([-1], [-1],[-1])).prefetch(tf.data.experimental.AUTOTUNE)
        fold_data.append((x_t,x_v))
    return fold_data,token




