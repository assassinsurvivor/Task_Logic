import re 
import os
import copy
import random
import pickle
import itertools
import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow_datasets as tfds

from random import shuffle
from tqdm import tqdm_notebook
from collections import defaultdict,Counter
from sklearn.preprocessing import OneHotEncoder


pattern_text=re.compile("[^a-z&-,\'\.]")

#reading data from db of various sic's(dictionary)
def filter_max_length(x,y,max_length=1200):
  return (tf.size(x) <= max_length)


def ETL():
    df=pd.read_excel("NLP_data_scientist_test/data/Entity_sentiment_trainV2.xlsx")
    extracted_corpus=df["Sentence"].apply(lambda x:x.lower()).tolist()
                  
    for idx,i in enumerate(extracted_corpus):
        extracted_corpus[idx]=" ".join(z.strip() for z  in (pattern_text.sub(" ",i).strip().split()))
        extracted_corpus[idx]=" ".join (u.strip() for u in (" . ".join(k for k in [i.strip() for i in extracted_corpus[idx].split(".")] if k!="").split()))

    try:
        tokenizer=tfds.features.text.SubwordTextEncoder.load_from_file("tokenizer/tokenizer")
    except:
        tokenizer=tfds.features.text.SubwordTextEncoder.build_from_corpus((i for i in extracted_corpus),target_vocab_size=12000,reserved_tokens=["<mask>"]) 
        if not os.path.isdir("tokenizer"):
            os.mkdir("tokenizer")
        tokenizer.save_to_file("tokenizer/tokenizer")

    id_mask=tokenizer.encode("<mask>")
    assert len(id_mask)==1
    
    encode_train_data=[];train_label=[]
    
    for idx,i in tqdm_notebook(enumerate(extracted_corpus)):
        temp_list=i.split(".")
        for k in temp_list:

            if random.random()>0.85:
                flush=tokenizer.encode(k+ " . ")
                encode_train_data.append(flush)
                train_label.append(flush)
            
            else:
                label_string=tokenizer.encode(k+" . ")
                split_string=copy.deepcopy(label_string)
                indices=np.random.choice(range(len(split_string)),1,replace=False)
                enc_temp=[c if c not in indices else id_mask[0] for c in split_string]
                encode_train_data.append(enc_temp)
                train_label.append(label_string)  


    print("Number of training samples before truncating to max sequence length of 1200:",len(encode_train_data))
    return encode_train_data,train_label,id_mask[0],tokenizer


def loader():
    data_train,data_label,idd,token=ETL()

    def generate_data():
        for _ in range(len(data_train)):
            yield data_train[_],data_label[_]


    batch_size=64
    buffer=1000000
    dataset=tf.data.Dataset.from_generator(generate_data,output_types=(tf.int32,tf.int32))
    x_t=dataset.filter(filter_max_length)
    x_t=x_t.cache().shuffle(buffer).padded_batch(batch_size,padded_shapes=([-1], [-1])).prefetch(tf.data.experimental.AUTOTUNE)
    return x_t,idd,token




