
# import the libraries
import os
import random
import numpy as np
import tensorflow as tf


import re
import argparse
import pandas as pd
import tensorflow_datasets as tfds

from random import shuffle
from tqdm import tqdm,tqdm_notebook
from language_dataloader import loader
from collections import Counter,defaultdict
from sklearn.preprocessing import OneHotEncoder
from encoder_model import scaled_dot_attention,MultiHeadAttn,encoder_layer,ffn
from encoder_model import BAttention,positional_embedding

parser = argparse.ArgumentParser(description='Model Hyper-Paramters')

parser.add_argument('--en',type=int,help='number of encoders')
parser.add_argument('--ed',type=int,help='embedding dimension of token')
parser.add_argument('--hd',type=int,help='embedding dimension of ffn layer')
parser.add_argument('--ah',type=int,help='number of attention head')
parser.add_argument('--dr',type=float,help='drop rate of dropout')
parser.add_argument('--ep',type=int,help='total epochs')
parser.add_argument('--dm',type=int,help='mask data to change after how many epochs? If 1 data would be same across all epochs')
p_parser=parser.parse_args()

#loading training data (tensors) -functions inherited from 'language_dataloader.py'
x_t,idd,token_text=loader()


#Model sub-layers are inherited from 'train_language_model.py' 
class LanguageModel(tf.keras.Model):
    
    def __init__(self,num_encoder_nx,embed_dim,higher_dim,num_attn_head,vocab_size,num_class,drop_rate=0.1):
        super(LanguageModel,self).__init__()
        
        #Total number of encoders .A encoder consists of multi-head(self) attention +ffn sub-layers.
        self.num_encoders=num_encoder_nx

        #Embedding matrix
        self.embedding=tf.keras.layers.Embedding(vocab_size,embed_dim,trainable=True)     
        
        #Positional encoding --Here max sequence length is 1200
        self.get_position_embed=positional_embedding(1200,embed_dim)  

        #Iterating over encoders                           
        self.encoders=[encoder_layer(embed_dim,num_attn_head,higher_dim,drop_rate) for i in range(self.num_encoders)]
        
        #Final linear layer
        self.final_layer=tf.keras.layers.Dense(num_class)

    
    def call(self,x,mask,is_train):
        
        sequence_length=tf.shape(x)[1]
        x_embedding=self.embedding(x)                            
        x_embedding+=self.get_position_embed[:,:sequence_length,:]
                
        for i in self.encoders:
            x_embedding=i(x_embedding,mask,is_train)

             
        x_encode=self.final_layer(x_embedding)
        return x_encode

#Building the model
encoder_model=LanguageModel(num_encoder_nx=p_parser.en,embed_dim=p_parser.ed,higher_dim=p_parser.hd,num_attn_head=p_parser.ah,vocab_size=token_text.vocab_size+2,num_class=token_text.vocab_size,drop_rate=p_parser.dr)
optimizer=tf.keras.optimizers.Adam(epsilon=1e-9)

#masking for attention logits -incase of padded tokens
def create_random_mask(inp,mask_rate):
  max_seq_length=tf.shape(inp)[-1].numpy()
  masked=tf.cast(tf.math.equal(inp,0),tf.float32).numpy()
  
  #Because cls token is the first token we need to subtract 1 from it
  if mask_rate>0:
    seq_length_wo_pad=np.argmax(masked,axis=-1)-1       
    
     #In-case there is no pad the argmax would give 0
    for _ in np.where(seq_length_wo_pad==0):           
      seq_length_wo_pad[_]=max_seq_length

    total_masks=seq_length_wo_pad*mask_rate
    total_masks=total_masks.astype(np.int32)

    for idx,i in enumerate(masked):
      if total_masks[idx]>0:
        masked[idx,np.random.choice(range(1,seq_length_wo_pad[idx]),total_masks[idx],replace=False)]=1
  masked=tf.cast(masked,tf.float32)
  masked=masked[:,tf.newaxis,tf.newaxis,:] 
  return masked

def create_classifier_mask(inp):
  return tf.cast(tf.math.equal(inp,idd),tf.float32)


#Train metrics
train_accuracy=tf.keras.metrics.SparseCategoricalAccuracy(name="train_accuracy")
train_loss=tf.keras.metrics.Mean(name="train_loss")
loss_object = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True, reduction='none')

def loss_function(real, pred,clf_mask):
  loss_ = loss_object(real, pred)
  mask = tf.cast(clf_mask, dtype=loss_.dtype)
  loss_ *= mask
  return tf.reduce_mean(loss_)

#creating graph for training 
inp_signature=[tf.TensorSpec(shape=(None,None),dtype=tf.int32),tf.TensorSpec(shape=(None,None),dtype=tf.int32),tf.TensorSpec(shape=(None,1,1,None),dtype=tf.float32),tf.TensorSpec(shape=(None,None),dtype=tf.float32),tf.TensorSpec(shape=(None),dtype=tf.bool)]
@tf.function(input_signature=inp_signature)
def train(inp,target,encoder_mask,clf_mask,flag):
    with tf.GradientTape() as tape:
        output=encoder_model(inp,encoder_mask,True)
        
        if flag==True:
            print(encoder_model.summary())
            flag=False
            
        loss_train = loss_function(target,output,clf_mask)
    
    gradients=tape.gradient(loss_train,encoder_model.trainable_variables)
    optimizer.apply_gradients(zip(gradients,encoder_model.trainable_variables))
    
    train_loss.update_state(loss_train)
    train_accuracy.update_state(target,output,clf_mask)


#saving checkpoints
if not os.path.isdir("drive/My Drive/logically_Model"):
    os.mkdir("drive/My Drive/logically_Model")

path="drive/My Drive/logically_Model/train/"
ckpt=tf.train.Checkpoint(encoder_model=encoder_model,optimizer=optimizer)
ckpt_manage=tf.train.CheckpointManager(checkpoint=ckpt,directory=path,max_to_keep=3)

if ckpt_manage.latest_checkpoint:
    ckpt.restore(ckpt_manage.latest_checkpoint)


if tf.test.is_gpu_available()==True:
  var="/gpu:0"
else:
  var="/cpu:0"

epochs=p_parser.ep

for epoch in range(epochs):

    if p_parser.dm!=1:
        if epoch!=0 and epoch%p_parser.dm==0:
            x_t,vocab_size,token_text=loader()
    
    train_loss.reset_states()
    train_accuracy.reset_states()
    
    for (batch,(inp,target)) in enumerate(x_t):
        train_calc_mask=create_random_mask(inp,0)
        clf_mask=create_classifier_mask(inp)
        
        
        if batch ==0 and epoch==0:
            with tf.device(var):
              train(inp,target,train_calc_mask,clf_mask,True)
              
        else:
            with tf.device(var):
              train(inp,target,train_calc_mask,clf_mask,False)
        
        if batch % 500 == 0 and batch!=0:
            print ('For epoch {}, batch {}  the loss is  {:.4f}  with accuracy of {:.4f}'.format(epoch + 1, batch, train_loss.result(), train_accuracy.result()))
            print("=================================================================")

        
      
    print ('For complete epoch {} loss is {:.4f} with accuracy {:.4f}'.format(epoch + 1, train_loss.result(), train_accuracy.result()))
    print("=================================================================")

    if epoch%200==0:
      ckpt_save = ckpt_manage.save()
      print ('Saving checkpoint for epoch {} at {}'.format(epoch+1,ckpt_save))
      print("=================================================================")


