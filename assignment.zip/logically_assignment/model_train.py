
# import the libraries
import os
import random
import numpy as np
import tensorflow as tf


import re
import argparse
import pandas as pd
import tensorflow_datasets as tfds

from random import shuffle
from tqdm import tqdm,tqdm_notebook
from model_dataloader import loader
from collections import Counter,defaultdict
from sklearn.preprocessing import OneHotEncoder
from encoder_model import scaled_dot_attention,MultiHeadAttn,encoder_layer,ffn
from encoder_model import HBAttention as BAttention,positional_embedding
from sklearn.metrics import average_precision_score
parser = argparse.ArgumentParser(description='Model Hyper-Paramters')

parser.add_argument('--en',type=int,help='number of encoders')
parser.add_argument('--ed',type=int,help='embedding dimension of token')
parser.add_argument('--hd',type=int,help='embedding dimension of ffn layer')
parser.add_argument('--ah',type=int,help='number of attention head')
parser.add_argument('--dr',type=float,help='drop rate of dropout')
parser.add_argument('--ep',type=int,help='total epochs')
p_parser=parser.parse_args()

#loading training data (tensors) -functions inherited from 'language_dataloader.py'
x_t,token_text=loader()


#Model sub-layers are inherited from 'train_language_model.py' 
class LanguageModel(tf.keras.Model):
    
    def __init__(self,num_encoder_nx,embed_dim,higher_dim,num_attn_head,vocab_size,num_class,drop_rate=0.1):
        super(LanguageModel,self).__init__()
        
        #Total number of encoders .A encoder consists of multi-head(self) attention +ffn sub-layers.
        self.num_encoders=num_encoder_nx

        #Embedding matrix
        self.embedding=tf.keras.layers.Embedding(vocab_size,embed_dim,trainable=True)     
        
        #Positional encoding --Here max sequence length is 1200
        self.get_position_embed=positional_embedding(1200,embed_dim)  

        #Iterating over encoders                           
        self.encoders=[encoder_layer(embed_dim,num_attn_head,higher_dim,drop_rate) for i in range(self.num_encoders)]
        
        #Attention layer
        self.attention=BAttention()

        #Final linear layer
        self.clf_layer=tf.keras.layers.Dense(num_class,activation='sigmoid')

    
    def call(self,x,mask,ent_mask,is_train):
        
        sequence_length=tf.shape(x)[1]
        x_embedding=self.embedding(x)                            
        x_embedding+=self.get_position_embed[:,:sequence_length,:]
                
        for i in self.encoders:
            x_embedding=i(x_embedding,mask,is_train)

        attn_mask=1-ent_mask
        x_em=self.attention(x_embedding,attn_mask)     
        x_encode=self.clf_layer(x_em)
        return x_encode

#Building the model
encoder_model=LanguageModel(num_encoder_nx=p_parser.en,embed_dim=p_parser.ed,higher_dim=p_parser.hd,num_attn_head=p_parser.ah,vocab_size=token_text.vocab_size+2,num_class=1,drop_rate=p_parser.dr)
optimizer=tf.keras.optimizers.Adam(epsilon=1e-9)

#masking for attention logits -incase of padded tokens
def create_random_mask(inp,mask_rate):
  max_seq_length=tf.shape(inp)[-1].numpy()
  masked=tf.cast(tf.math.equal(inp,0),tf.float32).numpy()
  
  #Because cls token is the first token we need to subtract 1 from it
  if mask_rate>0:
    seq_length_wo_pad=np.argmax(masked,axis=-1)-1       
    
     #In-case there is no pad the argmax would give 0
    for _ in np.where(seq_length_wo_pad==0):           
      seq_length_wo_pad[_]=max_seq_length

    total_masks=seq_length_wo_pad*mask_rate
    total_masks=total_masks.astype(np.int32)

    for idx,i in enumerate(masked):
      if total_masks[idx]>0:
        masked[idx,np.random.choice(range(1,seq_length_wo_pad[idx]),total_masks[idx],replace=False)]=1
  masked=tf.cast(masked,tf.float32)
  masked=masked[:,tf.newaxis,tf.newaxis,:] 
  return masked



#Train metrics
train_accuracy=tf.keras.metrics.BinaryAccuracy(name="train_accuracy")
train_loss=tf.keras.metrics.Mean(name="train_loss")
loss_object = tf.keras.losses.BinaryCrossentropy(from_logits=False,label_smoothing=0.1,reduction='none')
valid_accuracy=tf.keras.metrics.BinaryAccuracy(name="valid_accuracy")
valid_loss=tf.keras.metrics.Mean(name="valid_loss")

#creating graph for training 
inp_signature=[tf.TensorSpec(shape=(None,None),dtype=tf.int32),tf.TensorSpec(shape=(None),dtype=tf.int32),tf.TensorSpec(shape=(None,1,1,None),dtype=tf.float32),tf.TensorSpec(shape=(None,None),dtype=tf.float32),tf.TensorSpec(shape=(None),dtype=tf.bool)]
@tf.function(input_signature=inp_signature)
def train(inp,target,encoder_mask,ent_mask,flag):
    with tf.GradientTape() as tape:
        output=encoder_model(inp,encoder_mask,ent_mask,True)
        
        if flag==True:
            print(encoder_model.summary())
            flag=False
            
        loss_train = tf.reduce_mean(loss_object(target,output))
    
    gradients=tape.gradient(loss_train,encoder_model.trainable_variables)
    optimizer.apply_gradients(zip(gradients,encoder_model.trainable_variables))
    
    train_loss.update_state(loss_train)
    train_accuracy.update_state(target,output)

#creating graph for testing
inp_signature=[tf.TensorSpec(shape=(None,None),dtype=tf.int32),tf.TensorSpec(shape=(None),dtype=tf.int32),tf.TensorSpec(shape=(None,1,1,None),dtype=tf.float32),tf.TensorSpec(shape=(None,None),dtype=tf.float32)]
@tf.function(input_signature=inp_signature)
def validate(inp,target,encoder_mask,ent_mask):
    output=encoder_model(inp,encoder_mask,ent_mask,False)
    loss_test = tf.reduce_mean(loss_object(target,output))
    valid_loss.update_state(loss_test)
    valid_accuracy.update_state(target,output)


#creating graph for metric
inp_signature=[tf.TensorSpec(shape=(None,None),dtype=tf.int32),tf.TensorSpec(shape=(None),dtype=tf.int32),tf.TensorSpec(shape=(None,1,1,None),dtype=tf.float32),tf.TensorSpec(shape=(None,None),dtype=tf.float32)]
@tf.function(input_signature=inp_signature)
def metric(inp,target,encoder_mask,ent_mask):
    output=encoder_model(inp,encoder_mask,ent_mask,False)
    return output

#saving checkpoints
if not os.path.isdir("drive/My Drive/logically_Model"):
    os.mkdir("drive/My Drive/logically_Model")

path="drive/My Drive/logically_Model/train/"
ckpt=tf.train.Checkpoint(encoder_model=encoder_model,optimizer=optimizer)
ckpt_manage=tf.train.CheckpointManager(checkpoint=ckpt,directory=path,max_to_keep=3)

if ckpt_manage.latest_checkpoint:
    ckpt.restore(ckpt_manage.latest_checkpoint)


if tf.test.is_gpu_available()==True:
  var="/gpu:0"
else:
  var="/cpu:0"

epochs=p_parser.ep

for fold in x_t:
    for epoch in range(epochs):        
        train_loss.reset_states()
        train_accuracy.reset_states()
        
        for (batch,(inp,target,ent_mask)) in enumerate(fold[0]):
            train_calc_mask=create_random_mask(inp,0)
            
            
            if batch ==0 and epoch==0:
                with tf.device(var):
                  train(inp,target,train_calc_mask,ent_mask,True)
                  
            else:
                with tf.device(var):
                  train(inp,target,train_calc_mask,ent_mask,False)
            
            if batch % 100 == 0 and batch!=0:
                print ('For epoch {}, batch {}  the loss is  {:.4f}  with accuracy of {:.4f}'.format(epoch + 1, batch, train_loss.result(), train_accuracy.result()))
                print("=================================================================")

            
          
        print ('For complete epoch {} loss is {:.4f} with accuracy {:.4f}'.format(epoch + 1, train_loss.result(), train_accuracy.result()))
        print("=================================================================")

        
        #valid_loss.reset_states();valid_accuracy.reset_states()
        for (valid_batch,(inp,target,mask_ent)) in enumerate(fold[1]):
            valid_calc_mask=create_random_mask(inp,0) 
            with tf.device(var):
              validate(inp,target,valid_calc_mask,mask_ent)
        print ('Validation accuracy is {:.4f} with loss of {:.4f}'.format(valid_accuracy.result(),valid_loss.result()))
        print("=================================================================")
        
        # if input()=='yes':
        #   ckpt_save = ckpt_manage.save()
        #   print ('Saving checkpoint for epoch {} at {}'.format(epoch+1,ckpt_save))
        #   print("=================================================================")

    metrics=[]
    for (valid_batch,(inp,target,mask_ent)) in enumerate(fold[1]):
        valid_calc_mask=create_random_mask(inp,0) 
        with tf.device(var):
          out=metric(inp,target,valid_calc_mask,mask_ent)
          avg_precision=average_precision_score(target,out)
          metrics.append(avg_precision)

    print ('For the current fold the avergae precision recall score is : {:.4f} '.format(np.mean(np.array(metrics))))
    print("=================================================================")


